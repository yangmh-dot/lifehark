# Life Hack Copy Kit v2 (Light Theme)
Multi-category • A/B • Platform-optimized. Upload to GitHub Pages and open index.html.
